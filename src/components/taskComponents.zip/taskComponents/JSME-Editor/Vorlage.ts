import type {
  SerializedTaskComponent,
  SerialisedDependencies,
  ComponentDependencies,
  TaskGraphPath,
  ComponentProps,
  ComponentData
} 
from "@/components/taskComponents/TaskComponent";
import { TaskComponent } from "@/components/taskComponents/TaskComponent";
import type { ComputedRef } from "vue";
import { unref } from "vue";

export interface JSMEProps extends ComponentProps {
  
}

export type JSMEComponentType = "JSME";


export interface serialisedJSMEDependencies extends SerialisedDependencies {
 
}

export interface JSMEDependencies extends ComponentDependencies {
 
}

export interface JSMEComponentData extends ComponentData {
 
}

export interface SerializedJSMEComponent
  extends SerializedTaskComponent<JSMEComponentType, JSMEDependencies, JSMEComponentData> {}




export class JSMEComponent extends TaskComponent<
  SerializedJSMEComponent,
  serialisedJSMEDependencies,
  JSMEDependencies,
  JSMEComponentData
> {
  /**
   * The JSMEComponent class is a derived taskComponent, that is a template for actual CARPET UI-Elements.
   */
  public validate() {
    let isValid = true;
    unref(this.storeObject).setProperty({ path: `${this.serialisedTaskComponentPath}__isValid`, value: isValid });

    return isValid;
  }


  public JSApplet: any ;    

  public async loadJSME(JSMEsource: string = "https://jsme.cloud.douglasconnect.com/JSME_2017-02-26/jsme/jsme.nocache.js") {
      const script = document.createElement("script");
      script.src = JSMEsource;
      document.head.appendChild(script);
    
     
      // Nachdesm das Skript geladen wurde, instanziiere den Editor
      script.onload = async () => {
      console.log(window);
      // Verzögern Sie die Instanziierung, um sicherzustellen, dass JSApplet definiert ist
      await this.delay(800); // Sie müssen die delay-Methode implementieren
      console.log(window);
      // Instanziierung des Editors
      const store= unref(this.storeObject);
      const path=this.serialisedTaskComponentPath;
     function show_smiles(event:any) {
           const smiles = event.src.smiles(); //atom that are colored are numbered
           
          store.setProperty({ path: `${path}__smiles`, value: smiles});
        } 

      this.JSApplet = new (window as any).JSApplet.JSME("jsme_container","380px","320px");
        
      // Weitere Logik für die Behandlung des Editors oder Events hier einfügen

     
     
    this.JSApplet.setCallBack("AfterStructureModified", show_smiles);

    

    
      };
  }

  private delay(ms: number) {
      return new Promise(resolve => setTimeout(resolve, ms));
  }
  
}



